package com.example.explicitintense;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class activity2 extends AppCompatActivity {


    TextView tvAct2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        tvAct2= findViewById(R.id.tvAct2);

        String name =getIntent().getStringExtra("name");
        tvAct2.setText(name + ", Welcome to Page 2");

    }
}
